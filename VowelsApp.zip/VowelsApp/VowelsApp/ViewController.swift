//
//  ViewController.swift
//  VowelsApp
//
//  Created by Tata,Tejo Lakshmi on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var LetterOutlet: UITextField!
    
    
    @IBOutlet weak var DisplayOutlet: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        var i = LetterOutlet.text!
        //var d = DisplayOutlet.text!
        
        if i == "a" || i == "A" || i == "e" || i == "E" || i == "i" || i == "I" || i == "o" || i == "O" || i == "u" || i == "U"{
            
            DisplayOutlet.text = " This is Vowel";
            
        }else{
            DisplayOutlet.text = "This is Consonant";
        }
        
        
        
    }
    

}

