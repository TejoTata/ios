//
//  ViewController.swift
//  SamplePracticeApp
//
//  Created by Tata,Tejo Lakshmi on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var crs1Outlet: UITextField!
    
    @IBOutlet weak var crs2Outlet: UITextField!
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func buttonClicked(_ sender: Any) {
        //Read the course 1 name and store it ina variable
        var course1name = crs1Outlet.text!;
        //Read the course 2 name and store it in a variable
        var course2name = crs2Outlet.text!;
        //Perform String concatination and assign it to display(course1 - course2)
        displayLabelOutlet.text="\(course1name) - \(course2name)";
    }
    

}

