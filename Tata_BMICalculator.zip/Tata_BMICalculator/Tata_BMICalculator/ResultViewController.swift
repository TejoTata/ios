//
//  ResultViewController.swift
//  Tata_BMICalculator
//
//  Created by Tata,Tejo Lakshmi on 4/10/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var ResultImage: UIImageView!
    
    
    var outputImage = ""
    var result = ""
    
    @IBOutlet weak var ResultOutlet: UILabel!
    
    @IBAction func TouchmentBTN(_ sender: UIButton) {
        var x = ResultImage.frame.origin.x
        var y = ResultImage.frame.origin.y
        
        var x1 = ResultImage.frame.origin.x
        var y1 = ResultImage.frame.origin.y
        
        ResultImage.frame.origin.x = x1
        ResultImage.frame.origin.y = y1
        
        ResultOutlet.frame.origin.x = x
        ResultOutlet.frame.origin.y = y
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ResultImage.image = UIImage(named: "resultimg")
        ResultOutlet.text = result
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
