//
//  ViewController.swift
//  Tata_BMICalculator
//
//  Created by Tata,Tejo Lakshmi on 4/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var heightTF: UITextField!
    
    
    @IBOutlet weak var weightTF: UITextField!
    
    @IBOutlet weak var BMIbtnOutlet: UIButton!
    
    var bmiIndex = 0.0
    var ResultImage = ""
    var resultLabel = ""
    
    @IBAction func CalBMIBTN(_ sender: UIButton) {
        var height = Double(heightTF.text!) ?? 1.0
        var weight = Double(weightTF.text!) ?? 0.0
        
        bmiIndex = round((weight / (pow(height,2)))*10)/10
        
        ResultImage = "result"
        
        if (25 <= bmiIndex && bmiIndex <= 30){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Over Weight"
        }
        else if (bmiIndex < 18.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Under Weight"
        }
        else if (18.5 <= bmiIndex && bmiIndex <= 24.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Normal Weight"
        }
        else if (35 <= bmiIndex && bmiIndex <= 39.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Severe Obesity"
        }
        else if (40 <= bmiIndex && bmiIndex <= 44.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have morbid obesity"
        }
        
        else if (45 <= bmiIndex && bmiIndex <= 50){
            resultLabel = "Your BMI Index is \(bmiIndex).. It says that you have Super Obesity"
        }
    
        else{
            ResultImage = "error"
            resultLabel = "Enter Valid ddtails"
        }
        
    }

    @IBOutlet weak var HomepageImageOutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        HomepageImageOutlet.image = UIImage(named: "bmi")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "ResultSegue"{
                var destination = segue .destination as! ResultViewController
                
                destination.outputImage = ResultImage
                destination.result = resultLabel
                
                heightTF.text = ""
                weightTF.text = ""
                
            }
        }


}

