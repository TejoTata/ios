//
//  ViewController.swift
//  Tata_WordGuess
//
//  Created by Tata,Tejo Lakshmi on 3/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabe: UILabel!
    
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessLetterOutlet: UIButton!//outlet for guest a  letter btn
    
    
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
    
    
    var alphabet = guessLetterField.text!
               lettersGuessed = lettersGuessed + alphabet
               var revealedWord : String = ""
               for l in word{
                           if lettersGuessed.contains(l){
                               revealedWord += "\(l)"
                           }
                           else{
                               revealedWord += "_ "
                           }
                       }
               count += 1
                       //Assigning the word to guessLetterField after a guess
               userGuessLabel.text = revealedWord
               guessLetterField.text = ""
               guessCountLabel.text = "you have made \(count) guesses"
               if(count < maxNumOfWrongGuesses){
               //If the word is guessed correctly, we are enabling play again button and disabling the check button.
               if(userGuessLabel.text!.contains("_") == false){
                   
                   guessLetterOutlet.isEnabled = false
                   playAgainBTNOutlet.isHidden = false
                   displayImage.image = UIImage(named: words[guess][0])
                   guessCountLabel.text = "WOW! you have made \(count) guesss to guess the word!"
                   correct += 1
                   top()
               }
                   guessLetterOutlet.isEnabled = false
                   
               }
               else{
                   guessCountLabel.text = "You have used all the available guesses, Please play again"
                   playAgainBTNOutlet.isHidden = false
                   guessLetterOutlet.isEnabled = false
                   guess -= 1
               }
              
           }
           
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    var words = [["CAKE", "Food"],
                 ["DOG", "Animal"],
                 ["GLASSES","Eye wear"],
                 ["IPHONE", "Apple device"],
                 ["ROSE", "Flower"]]
        
        var guess = 0
        var word = ""
        var lettersGuessed = ""
        var count = 0
        let maxNumOfWrongGuesses = 10;
        var correct = 0
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            word = words[guess][0]
           top()
            guessLetterOutlet.isEnabled = true
            hintLabel.text = "Hint: "+words[guess][1];
            statusLabel.text = ""
            guessCountLabel.text = "You had made \(guess) guessess"
            updateUnderscores()
        }

    
    @IBOutlet weak var playAgainBTNOutlet: UIButton!
    
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        playAgainBTNOutlet.isHidden = true
               lettersGuessed = ""
                       guess += 1
                       //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
                       if guess == words.count{
                           guessCountLabel.text = ""
                           statusLabel.text = "Congruations! You are done with the game! \nPlease startover again"
                           //clearing the labels.
                           userGuessLabel.text = ""
                           hintLabel.text = ""
                           displayImage.image = UIImage(named: "alldone")
                           playAgainBTNOutlet.isHidden = false
                           //top()
                       }
                       else{
                           //fetch the next word from the array
                           word = words[guess][0]
                           //fetch the hint related to the word
                           hintLabel.text = "Hint: "
                           hintLabel.text! += words[guess][1]
                           //Enabling the check button.
                           guessLetterOutlet.isEnabled = true
                           guessCountLabel.text = ""
                           userGuessLabel.text = ""
                           updateUnderscores()
                           displayImage.image = UIImage()
                           count = 0
                       }
               if(correct == words.count){
                   correct = 0
                   top()
                   guess = -1
                   count = 0
                   
               }
               if guess == 0{
                   statusLabel.text = ""
               }
           }
    
    
    @IBAction func letterInput(_ sender: UITextField) {
        //Read the data from the text field
                      var textEnterd = guessLetterField.text!;
                      //Consider only the last character by calling textEntered.last and trimming the white spaces.
                      textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
                      guessLetterField.text = textEnterd
                      
                      //Check whether the entered text is empty or not to enable check button.
                      if textEnterd.isEmpty{
                          guessLetterOutlet.isEnabled = false
                      }
                      else{
                          guessLetterOutlet.isEnabled = true
                      }
               
           }
    
    
    
    
    
    @IBOutlet weak var displayImage: UIImageView!
    

//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do any additional setup after loading the view.
//    }
    
    
    
    func updateUnderscores(){
             for letter in word{
                 userGuessLabel.text! += "_ "
             }
         }
       func top(){
           wordsGuessedLabel.text = "Total number of words guessed successfully : \(correct)"
           wordsRemainingLabe.text = "Total number of words remaining in game : \(words.count - correct)"
           totalWordsLabel.text = "Total number of words in game : \(words.count)"
       }
   }




