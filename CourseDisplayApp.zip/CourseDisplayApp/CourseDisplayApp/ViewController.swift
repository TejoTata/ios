//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Tata,Tejo Lakshmi on 3/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imgOutlet: UIImageView!
    
    
   
    @IBOutlet weak var courseNumdisplay: UILabel!
    
    
   
    @IBOutlet weak var courseTittledisplay: UILabel!
    

    @IBOutlet weak var SemesterOffereddisplay: UILabel!
    
    
    @IBOutlet weak var prevBTN: UIButton!
    
    var imgNum = 0
    
    @IBOutlet weak var nxtBTN: UIButton!
    
    
    
    
    let courses = [["img01","44555","Network Security","Fall 2022"],
                   ["img02","44643","IOS","Spring 2023"],
                   ["img03","44656","Streaming Data","Fall 2024"]]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Load the first img (at 0th position)
        imgOutlet.image = UIImage(named: courses[0][0])
        //Load course details
        courseNumdisplay.text = courses[0][1]
        courseTittledisplay.text = courses[0][2]
        SemesterOffereddisplay.text = courses[0][3]
        //previous button disabled
        prevBTN.isEnabled=false
        //next btn is enabled
        nxtBTN.isEnabled=true
        
    }
    
    
    @IBAction func previousBTN(_ sender: UIButton) {
        //decrement the img num
        imgNum -= 1
        //update the course details
        imgOutlet.image = UIImage(named: courses[imgNum][0])
        courseNumdisplay.text = courses[imgNum][1]
        courseTittledisplay.text = courses[imgNum][2]
        SemesterOffereddisplay
            .text = courses[imgNum][3]
        //next btn enables
        nxtBTN.isEnabled=true
        
        //  once u reach the starting of the array ,previous btn disabled
        if(imgNum == 0){
            prevBTN.isEnabled=false
          
           
        }
    }
    
    
    
    
    @IBAction func nextBTN(_ sender: UIButton) {
        //increment imgNum
        imgNum += 1
        //update the details of the next course( img, num, tittle, sem off)
        imgOutlet.image = UIImage (named: courses[imgNum][0])
        courseNumdisplay.text = courses[imgNum][1]
        courseTittledisplay.text = courses[imgNum][2]
        SemesterOffereddisplay.text = courses[imgNum][3]
        //previous btn enabled
        prevBTN.isEnabled = true
        //when we reach the end of the aray , next btn should be disaabled.
        if(imgNum == courses.count-1){
            //reached the end of array
            nxtBTN.isEnabled=false
    }
    
    


}

}
