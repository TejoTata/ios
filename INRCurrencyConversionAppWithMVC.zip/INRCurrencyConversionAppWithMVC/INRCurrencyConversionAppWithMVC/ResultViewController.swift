//
//  ResultViewController.swift
//  INRCurrencyConversionAppWithMVC
//
//  Created by Tata,Tejo Lakshmi on 4/4/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var dollarOutletMVC: UILabel!
   
    
    @IBOutlet weak var dollarRateOutletMVC: UILabel!
    
    
    @IBOutlet weak var dollarToINRConversionMVC: UILabel!
    
    var dollar = ""
    var dollarRate = ""
    var result = ""
    var symbol = String("₹")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        dollarOutletMVC.text = dollarOutletMVC.text! + dollar
                
                
        dollarRateOutletMVC.text = dollarRateOutletMVC.text! +
        dollarRate
                
                
        dollarToINRConversionMVC.text = dollarToINRConversionMVC.text!  + result
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
