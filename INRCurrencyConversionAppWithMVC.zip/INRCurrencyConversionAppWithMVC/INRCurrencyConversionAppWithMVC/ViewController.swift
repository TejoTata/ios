//
//  ViewController.swift
//  INRCurrencyConversionAppWithMVC
//
//  Created by Tata,Tejo Lakshmi on 4/3/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var dollarOutlet: UITextField!
    
    @IBOutlet weak var currentDollarRateOutlet: UITextField!
    
    var dollarAfterConversion = 0.0
    
    
    @IBAction func ConversionBTNClicked(_ sender: UIButton) {
        //read the input from currency in dollar and current dollar rate and then perform multiplication
        var dollar = Double(dollarOutlet.text!)
        var dollarRate = Double(currentDollarRateOutlet.text!)
        dollarAfterConversion = dollar! * dollarRate!
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "ResultSegue"{
                var destination = segue .destination as! ResultViewController
                
                destination.dollar = dollarOutlet.text!
                destination.dollarRate = currentDollarRateOutlet.text!
                destination.result = String (dollarAfterConversion)
                
                dollarOutlet.text = ""
                currentDollarRateOutlet.text = ""
                
            }
        }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

