//
//  DietCollectionViewCell.swift
//  project
//
//  Created by Tejo Tata on 4/24/23.
//

import UIKit

class DietCollectionViewCell: UICollectionViewCell {
    
}
