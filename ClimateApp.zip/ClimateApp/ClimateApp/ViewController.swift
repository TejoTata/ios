//
//  ViewController.swift
//  ClimateApp
//
//  Created by Tata,Tejo Lakshmi on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var tempOutlet: UITextField!
    
    
    @IBOutlet weak var imageOutlet: UIImageView!
    

    @IBOutlet weak var displayOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func tempBTN(_ sender: UIButton) {
        //if temp less than -20 then disply snowfall image
        //if temp ,disply precipitation when range -19 to 20
        // if tem greater than 20 diplay sunny
        
        var temp = Int(tempOutlet.text!)
        
        
        if(temp!<0){
            imageOutlet.image = UIImage(named:"snowfall")
            
            
            
        } else if (temp!<20){
                imageOutlet.image = UIImage(named: "percipitation")
         
            }else
            {
                if(temp!>20){
                imageOutlet.image = UIImage(named:"sunny")
        }
  
    }
    
}
}

