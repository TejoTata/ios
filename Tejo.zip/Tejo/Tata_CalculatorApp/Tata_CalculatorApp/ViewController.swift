//
//  ViewController.swift
//  Tata_CalculatorApp
//
//  Created by Tata,Tejo Lakshmi on 2/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    @IBAction func BTNAc(_ sender: UIButton) {
    }
   
    @IBAction func BTNc(_ sender: Any) {
    }
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

