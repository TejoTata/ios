//
//  ViewController.swift
//  Tata_SearchApp
//
//  Created by Tata,Tejo Lakshmi on 3/19/23.
//

import UIKit


class ViewController: UIViewController {
    
    let animal_keywords = ["wild","pet","sea","mamals"]
       let cricketer_keywords = ["ball","bat","t20","ipl"]
       let flowers_keywords = ["fragrance","petels","leaves","roots"]
       let keyword = "invalid"
    
    var arr = [["cheeta","dog","egale","penguin","rabbit"], ["bumbrah","Dhoni","Hardik Pandya", "Ravindra Jadeja","Virat Kohli"] , ["lily","Orchid","rose","sunflower","tulip"]]
    
    var topics_array = [["The cheetah is a large cat native to Africa and Southwest Asia. It is the fastest land animal, capable of running at 80 to 98 km/h, as such has evolved specialized adaptations for speed, including a light build, long thin legs and a long tail.","The dog is a domesticated descendant of the wolf. Also called the domestic dog, it is derived from the extinct Pleistocene wolf, and the modern wolf is the dog's nearest living relative.","Eagle is the common name for many large birds of prey of the family Accipitridae. Eagles belong to several groups of genera, some of which are closely related. Most of the 68 species of eagles are from Eurasia and Africa.","Penguins are a group of aquatic flightless birds. They live almost exclusively in the Southern Hemisphere: only one species, the Galápagos penguin, is found north of the Equator. ","Rabbits are very curious, playful and social creatures that enjoy spending time with their owners. They can also enjoy socializing with other family members, children and pets with adult supervision. "],["Jasprit Jasbirsingh Bumrah is an Indian international cricketer who plays for the Indian national cricket team in all formats of the game. A right-arm fast bowler with a unique bowling action, Bumrah is considered one of the best fast bowlers in the world.","Mahendra Singh Dhoni, commonly known as MS Dhoni, is a former Indian cricketer and captain of the Indian national team in limited-overs formats from 2007 to 2017, and in Test cricket from 2008 to 2014. He is also the current captain of Chennai Super Kings in the Indian Premier League.","Hardik Himanshu Pandya is an Indian international cricketer who is the current vice-captain of the Indian cricket team in limited overs. An All-rounder who bats right-handed and bowls right-arm fast-medium, Pandya has played in all 3 formats for India.","Ravindrasinh Anirudhsinh Jadeja, commonly known as Ravindra Jadeja, is an Indian international cricketer. He is an all-rounder, who bats left-handed and bowls left-arm orthodox spin. He was the captain of the Chennai Super Kings in the Indian Premier League.","Virat Kohli is an Indian international cricketer and the former captain of the India national team who plays as a right-handed batsman for Royal Challengers Bangalore in the IPL and for the Delhi in Indian domestic cricket."],["Lilium is a genus of herbaceous flowering plants growing from bulbs, all with large prominent flowers. They are the true lilies. Lilies are a group of flowering plants which are important in culture and literature in much of the world.","Orchids are plants that belong to the family Orchidaceae, a diverse and widespread group of flowering plants with blooms that are often colourful and fragrant. Along with the Asteraceae, the Orchidaceae is one of the two largest families of flowering plants.","A rose is either a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars. ","Helianthus is a genus comprising about 70 species of annual and perennial flowering plants in the daisy family Asteraceae commonly known as sunflowers. Except for three South American species, the species of Helianthus are native to North America and Central America. The best-known species is the common sunflower.","Tulips are a genus of spring-blooming perennial herbaceous bulbiferous geophytes. The flowers are usually large, showy and brightly coloured, generally red, pink, yellow, or white. They often have a different coloured blotch at the base of the tepals, internally."]]
    
    var topic = -1

    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    
    
    
    @IBAction func schAction(_ sender: Any) {
        if(searchTextField.text == ""){
            searchBtnOutlet.isEnabled = false
                   prevBtnOutlet.isHidden = true
            nxtBtnOutlet.isHidden = true
            resetBtnOutlet.isHidden = true
                   topicInfoText.text = ""
                   }
               else{
                   searchBtnOutlet.isEnabled = true
                   resultImage.image = UIImage()
                   
                   
               }
           }
    
    @IBOutlet weak var searchBtnOutlet: UIButton!//outlet for search btn
    
    @IBOutlet weak var prevBtnOutlet: UIButton!//outlet previous btn
    
    @IBOutlet weak var nxtBtnOutlet: UIButton!//outlet for next btn
    
    @IBOutlet weak var resetBtnOutlet: UIButton!//outlet for reset btn
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        var look : String = searchTextField.text!
               
               prevBtnOutlet.isHidden = false
               nxtBtnOutlet.isHidden = false
               resetBtnOutlet.isHidden = false
               prevBtnOutlet.isEnabled = false
               

               //to search a non keyword
               if (searchTextField.text == keyword){
                   resultImage.image = UIImage(named: "oops")
                   topicInfoText.text = ""
                   prevBtnOutlet.isHidden = true
                   nxtBtnOutlet.isHidden = true
                   resetBtnOutlet.isHidden = true
                   
               }
           
               else if(animal_keywords.contains(look) ){
                   //displaying that image
                   topic = 0
                   resultImage.image = UIImage(named: arr[topic][0])
                   topicInfoText.text = topics_array[topic][0]
                   }
               else if(cricketer_keywords.contains(look)){
                   topic = 1
                   resultImage.image = UIImage(named: arr[topic][0])
                   topicInfoText.text = topics_array[topic][0]
               }
               else if(flowers_keywords.contains(look)){
               topic = 2
                   
                   resultImage.image = UIImage(named: arr[topic][0])
                   topicInfoText.text = topics_array[topic][0]
               }
               else{
                   resultImage.image = UIImage(named: "oops")
                   topicInfoText.text = ""
                   prevBtnOutlet.isHidden = true
                   nxtBtnOutlet.isHidden = true
                   resetBtnOutlet.isHidden = true
                   
                   
               }
            
    }
    
    @IBOutlet weak var resultImage: UIImageView!
    
    var iNum = 0
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        nxtBtnOutlet.isEnabled = true
        
               if(iNum == 1){
                   prevBtnOutlet.isEnabled = false
                   iNum = 0
                   resultImage.image = UIImage(named: arr[topic][iNum])
                   topicInfoText.text = topics_array[topic][iNum]
                   
               }
               else{
                   iNum -= 1
                   resultImage.image = UIImage(named: arr[topic][iNum])
                   topicInfoText.text = topics_array[topic][iNum]
                   prevBtnOutlet.isEnabled = true
                   
                   }

    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        searchBtnOutlet.isEnabled = false
        prevBtnOutlet.isHidden = true
        nxtBtnOutlet.isHidden = true
        resetBtnOutlet.isHidden = true
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
    }
    
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        iNum += 1
               
               //when we reach the end of array next button should be disabled
               if(iNum == arr[topic].count-1){
                   //reach the end of array
                   nxtBtnOutlet.isEnabled = false
                   resultImage.image = UIImage(named: arr[topic][iNum])
                   topicInfoText.text = topics_array[topic][iNum]
               }
               else{
                   resultImage.image = UIImage(named: arr[topic][iNum])
                   topicInfoText.text = topics_array[topic][iNum]
                   //NextBtn.isEnabled = true
                   prevBtnOutlet.isEnabled = true
               }

    }
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBtnOutlet.isEnabled = false
        prevBtnOutlet.isHidden = true
        nxtBtnOutlet.isHidden = true
        resetBtnOutlet.isHidden = true
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
   
        // Do any additional setup after loading the view.
    }


}

