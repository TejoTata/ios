//
//  ViewController.swift
//  Tata_Assignment01
//
//  Created by Tata,Tejo Lakshmi on 1/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    @IBOutlet weak var detailsOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        //read the firstname and laste name and dob (year) and store it in a variable
        var first=firstNameOutlet.text!
        
        var last=lastNameOutlet.text!
        
        var text=yearOutlet.text ?? ""
        var i=Int(text) ?? 0//i is user entered year
        
        let currentDate = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: currentDate)//getting system year(current year)
        var cal:Int=year-i
        
        //assign firstname to fullname label ,lastename to initials label and cal (year) to the age label
        fullNameLabel.text=("Full Name is :\(first)")
        initialsLabel.text="Initials are : \(last.first!) \(first.first!)"
        ageLabel.text="Age is: \(cal)"

        
    }
    
   
    @IBAction func ResetBTN(_ sender: UIButton) {
        
        //assign firstname ,lastename  and dob (year) to empty string , so that when we click submit it will clear values
        firstNameOutlet.text=" "
        lastNameOutlet.text=" "
        yearOutlet.text=" "
        fullNameLabel.text=" "
        initialsLabel.text=" "
        ageLabel.text=" "
        detailsOutlet.text=" "
        
    }
    

}

