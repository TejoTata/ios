import UIKit

var greeting = "Hello, Tejo"

var marks=15 ;
if marks>50{
    print("The Student had passed with \(marks) marks");
}else{
    print("The student had managed to get \(marks) marks");
}

var male:Bool=false
var age = 4
if male {
    if age<20 {
        print("BOY");
    }else{
        print("MAN")
    }
}else{
    if age<20{
        print("GIRL");
    }else{
        print("Women")
    }
}

// for loop
//printing mul table
var num:Int = 12;
for index in 1...10{
    print("\(num)*\(index)=\(num*index)");
}
//sum of n numbers
var totalNum = 10;
var sum:Int = 0
for number in 1...totalNum{
    sum+=number
}
print("The sum of first \(totalNum) is \(sum)");






