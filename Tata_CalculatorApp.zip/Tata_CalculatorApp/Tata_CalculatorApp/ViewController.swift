//
//  ViewController.swift
//  Tata_CalculatorApp
//
//  Created by Tata,Tejo Lakshmi on 2/13/23.
//

import UIKit

class ViewController: UIViewController {
   
    var operator1:String = " "
    var operator2:String = " "
    var operator3:Character = " ";
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    @IBAction func buttonAC(_ sender: UIButton) {
        resultOutlet.text = " "
                operator1 = " "
                operator2 = " "
                operator3 = " "

    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        if(operator2 != " "){
                    operator2=String(operator2[operator2.startIndex..<operator2.index(operator2.endIndex,offsetBy: -1)])
                    
                    resultOutlet.text=operator2
                    
                }
                
                else if(operator1 != " "){
                    operator1=String(operator1[operator1.startIndex..<operator1.index(operator1.endIndex,offsetBy: -1)])
                    resultOutlet.text=operator1
                    
                }

    }
    
   
    @IBAction func buttonSignChange(_ sender: UIButton) {
        if(operator2 != " "){
                    if(operator2.contains(".")){
                        operator2 = "\(-Double(operator2)!)"
                        resultOutlet.text=operator2
                    }
                    else{
                        operator2 = "\(-Int(operator2)!)"
                        resultOutlet.text=operator2
                    }
                    
                }
                else if(operator1 != " ") {
                    if(operator1.contains(".")){
                        operator1 = "\(-Double(operator1)!)"
                        resultOutlet.text=operator1
                    }
                    else{
                        operator1 = "\(-Int(operator1)!)"
                        resultOutlet.text=operator1
                    }
                }
    }
    
    
    @IBAction func buttonDiv(_ sender: UIButton) {
        operator3="/"

    }
    
    @IBAction func buttonSeven(_ sender: UIButton) {
        
        if (operator1 == " " && operator3 == " " ){
            operator1="7"
            resultOutlet.text="\(operator1)"
        }else if(operator1 != " " && operator3 == " " ){
            operator1=operator1+"7"
            resultOutlet.text="\(operator1)"
        }
        else if(operator2 == " " && operator3 != " "){
            operator2 = "7"
            resultOutlet.text="\(operator2)"
        }
        else if(operator2 != " "){
            operator2=operator2+"7"
            resultOutlet.text="\(operator2)"
        }
        
    }
    
    @IBAction func buttonEight(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                    operator1="8"
                    resultOutlet.text="\(operator1)"
                }else if(operator1 != " " && operator3 == " " ){
                    operator1=operator1+"8"
                    resultOutlet.text="\(operator1)"
                }
                else if(operator2 == " " && operator3 != " "){
                    operator2 = "8"
                    resultOutlet.text="\(operator2)"
                }
                else if(operator2 != " "){
                    operator2=operator2+"8"
                    resultOutlet.text="\(operator2)"
                }
    }
    
    @IBAction func buttonNine(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                    operator1="9"
                    resultOutlet.text="\(operator1)"
                }else if(operator1 != " " && operator3 == " " ){
                    operator1=operator1+"9"
                    resultOutlet.text="\(operator1)"
                }
                else if(operator2 == " " && operator3 != " "){
                    operator2 = "9"
                    resultOutlet.text="\(operator2)"
                }
                else if(operator2 != " "){
                    operator2=operator2+"9"
                    resultOutlet.text="\(operator2)"
                }
                
    }
    
    
    @IBAction func buttonMul(_ sender: UIButton) {
        operator3="*"
    }
    
    
    @IBAction func buttonFour(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                    operator1="4"
                    resultOutlet.text="\(operator1)"
                }else if(operator1 != " " && operator3 == " " ){
                    operator1=operator1+"4"
                    resultOutlet.text="\(operator1)"
                }
                else if(operator2 == " " && operator3 != " "){
                    operator2 = "4"
                    resultOutlet.text="\(operator2)"
                }
                else if(operator2 != " "){
                    operator2=operator2+"4"
                    resultOutlet.text="\(operator2)"
                }
                
        
    }
    
    @IBAction func buttonFive(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                   operator1="5"
                   resultOutlet.text="\(operator1)"
               }else if(operator1 != " " && operator3 == " " ){
                   operator1=operator1+"5"
                   resultOutlet.text="\(operator1)"
               }
               else if(operator2 == " " && operator3 != " "){
                   operator2 = "5"
                   resultOutlet.text="\(operator2)"
               }
               else if(operator2 != " "){
                   operator2=operator2+"5"
                   resultOutlet.text="\(operator2)"
               }
              
    }
    
    @IBAction func buttonSix(_ sender: UIButton) {
        
        if (operator1 == " " && operator3 == " " ){
            operator1="6"
            resultOutlet.text="\(operator1)"
        }else if(operator1 != " " && operator3 == " " ){
            operator1=operator1+"6"
            resultOutlet.text="\(operator1)"
        }
        else if(operator2 == " " && operator3 != " "){
            operator2 = "6"
            resultOutlet.text="\(operator2)"
        }
        else if(operator2 != " "){
            operator2=operator2+"6"
            resultOutlet.text="\(operator2)"
        }
        
    }
    
  
    @IBAction func buttonSub(_ sender: UIButton) {
        operator3="-"
    }
    
    @IBAction func buttonOne(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                   operator1="1"
                   resultOutlet.text="\(operator1)"
               }else if(operator1 != " " && operator3 == " " ){
                   operator1=operator1+"1"
                   resultOutlet.text="\(operator1)"
               }
               else if(operator2 == " " && operator3 != " "){
                   operator2 = "1"
                   resultOutlet.text="\(operator2)"
               }
               else if(operator2 != " "){
                   operator2=operator2+"1"
                   resultOutlet.text="\(operator2)"
               }
              
    }
    
    @IBAction func buttonTwo(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                   operator1="2"
                   resultOutlet.text="\(operator1)"
               }else if(operator1 != " " && operator3 == " " ){
                   operator1=operator1+"2"
                   resultOutlet.text="\(operator1)"
               }
               else if(operator2 == " " && operator3 != " "){
                   operator2 = "2"
                   resultOutlet.text="\(operator2)"
               }
               else if(operator2 != " "){
                   operator2=operator2+"2"
                   resultOutlet.text="\(operator2)"
               }
               
           }
    
    
    @IBAction func buttonThree(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                    operator1="3"
                    resultOutlet.text="\(operator1)"
                }else if(operator1 != " " && operator3 == " " ){
                    operator1=operator1+"3"
                    resultOutlet.text="\(operator1)"
                }
                else if(operator2 == " " && operator3 != " "){
                    operator2 = "3"
                    resultOutlet.text="\(operator2)"
                }
                else if(operator2 != " "){
                    operator2=operator2+"3"
                    resultOutlet.text="\(operator2)"
                }
                
    }
    
    
    @IBAction func buttonAdd(_ sender: UIButton) {
        operator3="+"
    }
    
    @IBAction func buttonZero(_ sender: UIButton) {
        if (operator1 == " " && operator3 == " " ){
                   operator1="0"
                   resultOutlet.text="\(operator1)"
               }else if(operator1 != " " && operator3 == " " ){
                   operator1=operator1+"0"
                   resultOutlet.text="\(operator1)"
               }
               else if(operator2 == " " && operator3 != " "){
                   operator2 = "0"
                   resultOutlet.text="\(operator2)"
               }
               else if(operator2 != " "){
                   operator2=operator2+"0"
                   resultOutlet.text="\(operator2)"
               }
              
    }
    
    
    @IBAction func buttonDot(_ sender: UIButton) {
        if(operator1 == " " && operator3 == " "){
                    operator1="0."
                    resultOutlet.text="\(operator1)"
                }else if(operator1 != " " && operator3 == " "){
                    operator1=operator1+"."
                    resultOutlet.text="\(operator1)"
                }
                else if(operator2 == " " && operator3 != " "){
                    operator2="0."
                    resultOutlet.text="\(operator2)"
                }else if(operator2 != " "){
                    operator2=operator2+"."
                    resultOutlet.text="\(operator2)"
                }
    }
    
    @IBAction func buttonMod(_ sender: UIButton) {
        operator3="%"
    }
    
    @IBAction func buttonEqualto(_ sender: UIButton) {
        
        switch operator3{
        case "+" :
            if(operator1.contains(".")){
                let val = "\(Double(operator1)! + Double(operator2)!)"
                let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                if(dec != "0"){
                    resultOutlet.text = val
                }
                else{
                    resultOutlet.text = "\(Int(Double(operator1)! + Double(operator2)!))"
                }
                
            }
            else {
                resultOutlet.text = "\(Int(operator1)! + Int(operator2)!)"
            }
            
        case "-" :
         
            if(operator1.contains(".")){
                resultOutlet.text = "\(Double(operator1)! - Double(operator2)!)"
            }
            else {
                resultOutlet.text = "\(Int(operator1)! - Int(operator2)!)"
            }
        
        case "*" :
            if(operator1.contains(".")){
                resultOutlet.text = "\(Double(operator1)! * Double(operator2)!)"
            }
            else {
                resultOutlet.text = "\(Int(operator1)! * Int(operator2)!)"
            }
            
        case "/" :
            if(operator1.contains(".")){
                resultOutlet.text = "\(Double(operator1)! / Double(operator2)!)"
            }
            else {
                if(operator2 == "0"){
                    resultOutlet.text = "Not a number"
                }
                else{
                    let val = "\(Double(operator1)! / Double(operator2)!)"
                    let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                    let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                    if(dec != "0"){
                        resultOutlet.text = "\(round(Double(val)!*100000)/100000)"
                    }
                    else{
                        resultOutlet.text = "\(Int(operator1)! / Int(operator2)!)"
                    }
                }
                
            }
            
        case "%" :
            
            if(operator1.contains(".")){
                var val = Double(operator1)!.truncatingRemainder(dividingBy: Double(operator2)!)
                resultOutlet.text = "\(round(val*10)/10)"
            }
            else {
                resultOutlet.text = "\(Int(operator1)! % Int(operator2)!)"
            }
        
            
        default:
            print("no operation")
     
        
       }

        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

